# ASR robustness results: Whisper under synthetic Gaussian noise

**This is a 20-utterance pilot using synthetic Gaussian noise.** It reports no confidence intervals and makes no claim that the results generalize to real acoustic environments.

## Configuration

| Setting | Value |
|---|---|
| Model | `openai/whisper-tiny.en` |
| Dataset | `openslr/librispeech_asr` (config `clean`, split `test`) |
| Seed | 42 |
| Utterances | 20 (identical IDs and references in every condition) |
| Conditions | `clean`, `snr_20db`, `snr_10db`, `snr_5db` |
| Requested SNR levels (dB) | 20, 10, 5 |
| Device | `cuda` |
| Report schema version | 2 |
| Input file | `robustness_results.json` (SHA-256 `828eec70a024ad746aa9f78e01589a5247942969dd7f276599cabe1bf85df6f3`) |

## Sample size

- Utterances per condition: **20** (4 conditions, 80 transcriptions in total).
- Reference size: 349 words and 1870 characters (whitespace-split, before the scoring normalization).
- No selected utterances used the long-form path: all 20 fit within one 30-second Whisper window.

## Corpus-level error rates

Corpus WER/CER are total errors divided by total reference words/characters, taken directly from the experiment JSON (not averaged over utterances).

| Condition | Requested SNR (dB) | Mean measured SNR (dB) | Corpus WER (%) | Corpus CER (%) |
|---|---|---|---|---|
| Clean | — | — | 8.88 | 3.70 |
| 20 dB | 20 | 20.00 | 8.60 | 4.02 |
| 10 dB | 10 | 10.00 | 17.19 | 8.89 |
| 5 dB | 5 | 5.00 | 27.51 | 15.69 |

## Change versus clean

Absolute change is in percentage points (pp); relative change is the change as a percentage of the clean value. Both use the `clean` condition of this same report.

| Condition | WER change (pp) | WER change (relative) | CER change (pp) | CER change (relative) |
|---|---|---|---|---|
| 20 dB | -0.29 | -3.2% | +0.32 | +8.7% |
| 10 dB | +8.31 | +93.5% | +5.20 | +140.6% |
| 5 dB | +18.62 | +209.7% | +12.00 | +324.6% |

Highest corpus WER in this pilot: **5 dB** (27.51%).

## Baseline note

The earlier `results/clean_baseline.json` came from the earlier pipeline-based pilot (a different inference path). Compare noisy conditions only against the `clean` condition in `robustness_results.json`, which uses the same code path, utterances and decoding settings as the noisy conditions.

## Limitations

- **Small pilot:** 20 utterances from one LibriSpeech test-clean subset; single seed, single run, one noise realization per utterance and SNR level.
- **No uncertainty estimates:** no confidence intervals, significance tests or repeated-seed variability are reported, so small differences should not be interpreted.
- **Synthetic noise only:** white Gaussian noise added at a power-based SNR. This is not evidence about real acoustic environments (colored or non-stationary noise, reverberation, microphones, accents, other languages).
- **One model and decoding setup:** `openai/whisper-tiny.en` with greedy decoding; results do not transfer to other model sizes or decoders.
- **Read speech:** LibriSpeech test-clean is clean, read, English audiobook speech.
- **Scoring policy:** WER/CER use the project's normalization (lowercasing, apostrophes removed, other punctuation treated as spaces).
- **Relative changes** are unstable when the clean error rate is small; prefer the absolute (pp) changes.
- **Inference times** in the JSON are not benchmarks (the first condition can include device warm-up) and are not analysed here.
